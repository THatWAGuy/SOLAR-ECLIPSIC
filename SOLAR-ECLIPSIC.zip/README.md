# SOLAR-ECLIPSIC


mod for the hit indie game eclipsic

Newest version of Eclipsic: https://www.mediafire.com/file/xnkvnqqyr0d23ap/Ecl_EA_beta_0.0.2.3.zip/file

anyone can contribute to the mod btw


# ok so items

## Labradorite Pickaxe
-  Type: Tool, Pickaxe
-  Speed: 10
-  Range: 9
-  Strength: 5
-  ToolTip: "Oh boy a mod that adds a PICKAXE??? how ORIGINAL."

## Reinforced Emerald Staff
-  Type: Weapon, Multi-summoning item
-  Speed: A lot
-  Summon: Rolling Sentry
-  ToolTip: "Oh god an op summoner weapon"
