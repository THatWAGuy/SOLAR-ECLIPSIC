function update(deltaTime, thisProjectile)
end

function onHitWall(thisProjectile)
end

function onHitEntity(thisProjectile, collidingEntity)
end

function onHitProjectile(thisProjectile, otherProjectile)
end