function update(deltaTime, thisMob)
end

function onHitWall(thisMob)
end

function onHitEntity(thisMob, otherEntity)
end

function onDraw(thisMob)
end